package _01_veriables;

public class Q02 {
	
	public static void main(String[] args) {

		/*
		 * Primitive data type
		 * boolean, char, byte, short, integer,long, double, float
		 * 
		 */
		
		//byte, short, integer,long, double, float veri tiplerinin max ve min degerlerini yazdiriniz.
		

		
		
		
	}

}
