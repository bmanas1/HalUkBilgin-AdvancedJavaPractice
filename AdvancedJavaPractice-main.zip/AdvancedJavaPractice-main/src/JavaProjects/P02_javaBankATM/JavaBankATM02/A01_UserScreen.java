package JavaProjects.P02_javaBankATM.JavaBankATM02;
import static JavaProjects.P02_javaBankATM.JavaBankATM02.A02_InfoControl.atmStart;

public class A01_UserScreen {

    public static void main(String[] args) {
        System.out.println("*************************************");
        System.out.println("******** Welcome to JavaBank ********");
        atmStart();

    }
}
