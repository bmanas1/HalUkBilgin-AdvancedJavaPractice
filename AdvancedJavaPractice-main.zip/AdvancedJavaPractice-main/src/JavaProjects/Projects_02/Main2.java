package JavaProjects.Projects_02;

public class Main2 {
    public static void main(String[] args) {
        System.out.println(2);
    }
}
