package JavaProjects.P08_HastaneOtomasyon;

public class VeriBankasi {

	String[] doctorIsimleri = { "Nilson", "John", "Robert", "Marry", "Alan", "Mahesh" };
	String[] doctorSoyIsimleri= { "Avery", "Abel", "Erik", "Jacob", "Pedro", "Tristen" };
	
	String[] unvanlar = { "Allergist", "Norolog", "Genel cerrah", "Cocuk doktoru", "Dahiliye", "Kardiolog" };
	
	String[] hastaIsimleri = { "Warren", "Petanow", "Sophia", "Emma", "Darian", "Peter" };
	String[] hastaSoyIsimleri= { "Traven", "William", "George", "Tristan", "Luis", "Cole"};
	
	String[] durumlar= { "Allerji", "Bas agrisi", "Diabet", "Soguk alginligi", "Migren", "Kalp hastaliklari"};
	
	int [] hastaIDleri = {111,222,333,444,555,666};


}
