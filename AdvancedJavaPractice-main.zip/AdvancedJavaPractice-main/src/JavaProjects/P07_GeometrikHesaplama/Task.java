package JavaProjects.P07_GeometrikHesaplama;




/* 1-asagidaki hiyarasiye gore class creat ediniz...

     sekil <--Cember
     sekil <--Dikdortgen<--Kare

    2- Turetilen class'a uygun olanlarina yaricap,  uzunluk ve genislik ekleyiniz.
    3- Runner class'da obj'lerin  alan ve cevre hesaplamasi yaptirip sonuclari yazdiriniz.
    */


public class Task {

}
