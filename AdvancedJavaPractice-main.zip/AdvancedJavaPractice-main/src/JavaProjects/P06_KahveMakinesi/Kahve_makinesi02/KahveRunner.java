package JavaProjects.P06_KahveMakinesi.Kahve_makinesi02;

public class KahveRunner {
    public static void main(String[] args) {
        HangiKahve khv =new HangiKahve();
        khv.startKahve();
    }
}
