package JavaProjects.P04_okulYönetimi.notHesap;

public class Course {

    Teacher teacher;
    String name;
    String prefix;
    int noteYazili;
    int noteSozlu;




}