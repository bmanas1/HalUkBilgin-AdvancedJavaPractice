package JavaProjects.P04_okulYönetimi.notHesap;

public class Teacher {

    private String name;
    private String branch;



}