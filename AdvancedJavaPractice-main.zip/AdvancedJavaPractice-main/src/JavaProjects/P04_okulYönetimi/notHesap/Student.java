package JavaProjects.P04_okulYönetimi.notHesap;

public class Student {

    Course mat;
    Course tur;
    Course bio;
    double cAvarage;
    String name;
    String stuNo;
    String classes;



}