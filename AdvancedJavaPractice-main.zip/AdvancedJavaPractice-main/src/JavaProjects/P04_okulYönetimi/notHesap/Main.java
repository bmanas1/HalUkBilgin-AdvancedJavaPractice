package JavaProjects.P04_okulYönetimi.notHesap;


public class Main {

    public static void main(String[] args) {


    }
}