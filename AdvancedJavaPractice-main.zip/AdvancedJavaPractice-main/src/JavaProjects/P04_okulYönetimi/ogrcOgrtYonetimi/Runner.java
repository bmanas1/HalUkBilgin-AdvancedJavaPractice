package JavaProjects.P04_okulYönetimi.ogrcOgrtYonetimi;


import static JavaProjects.P04_okulYönetimi.ogrcOgrtYonetimi.Islemler.girisPaneli;

public class Runner {
    public static void main(String[] args) {
        girisPaneli();//static method import edildi
    }
}
